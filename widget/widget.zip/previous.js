var data = {
  companyFields: [
    { value: "1", label: "Email" },
    { value: "2", label: "Web" },
    { value: "3", label: "Адрес" },
    { value: "4", label: "Примечание" },
    { value: "5", label: "Почтовый адрес" },
    { value: "6", label: "Последняя оплата" },
    { value: "7", label: "Уровень компании" },
    { value: "8", label: "Сумма оплат за 6 мес." },
  ],
  leadFields: [
    { value: "1", label: "Сообщ. в Телеграм" },
    { value: "2", label: "Кол-во успешных сделок за 6 мес." },
    { value: "3", label: "на дату" },
    { value: "4", label: "Этап 'Завершены работы'" },
    { value: "5", label: "Сделка для возврата залога?" },
    { value: "6", label: "Воронка Первичное этап Закрыто" },
  ],
  contactFields: [
    { value: "1", label: "Примечание" },
    { value: "2", label: "Регион" },
    { value: "3", label: "Уровень контакта" },
    { value: "4", label: "Кол-во успешных сделок за 6 мес." },
    { value: "5", label: "roistat" },
  ],
  dependencyType: [
    { value: "1", label: "От количества" },
    { value: "2", label: "От суммы" },
  ],
  entityType: [
    { value: "contact", label: "Контакт" },
    { value: "company", label: "Компания" },
  ],
};

define(["./templates.js"], function (templatesRenderer) {
  class Widget {
    constructor(widget, getTemplate) {
      this.widget = widget;
      this.getTemplate = getTemplate;
      this.isDestroyed = false;
    }

    optionsToItems({ options, values, prefix } = {}) {
      return options.reduce((items, option) => {
        let item = { id: option.value, option: option.label };

        if (values && prefix) {
          item.name = `${prefix}${option.value}`;
          item.is_checked = values.includes(option.value);
          item.option = `${option.group}. ${item.option}`;
        }

        items.push(item);
        return items;
      }, []);
    }

    addDeleteButtonListeners() {
      var tbody = document.querySelector("#status-tab tbody");
      tbody.addEventListener("click", e => {
        if (
          e.target &&
          e.target.nodeName == "SPAN" &&
          e.target.id == "delete-row-icon"
        ) {
          var deleteBtns = $("#delete-row-icon");
          // var deleteBtns = document.querySelectorAll("#delete-row-icon");
          deleteBtns = Array.from(deleteBtns);
          var rows = $("#status-tab tbody > tr");
          // var rows = document.querySelectorAll("#status-tab tbody > tr");
          rows = Array.from(rows);
          rows[deleteBtns.indexOf(e.target)].remove();
        }
      });
    }

    // addEntityTypeListeners() {
    //   var tbody = document.querySelector("#status-tab tbody");
    //   tbody.addEventListener("click", e => {
    //     if (e.target && e.target) {
    //     }
    //   });
    // }

    addRowListeners() {
      var tbody = document.querySelector("#status-tab tbody");
      tbody.addEventListener("click", e => {
        alert(e.target);
        // if (
        //   e.target &&
        //   e.target.nodeName == "SPAN" &&
        //   e.target.id == "delete-row-icon"
        // ) {
        //   var deleteBtns = $("#delete-row-icon");
        //   // var deleteBtns = document.querySelectorAll("#delete-row-icon");
        //   deleteBtns = Array.from(deleteBtns);
        //   var rows = $("#status-tab tbody > tr");
        //   // var rows = document.querySelectorAll("#status-tab tbody > tr");
        //   rows = Array.from(rows);
        //   rows[deleteBtns.indexOf(e.target)].remove();
        // }
      });
      // var deps = document.querySelectorAll("#dependency-type");
      // deps.forEach(dep => {
      //   dep.addEventListener("change", alert("value " + dep.value));
      // });
      // var rows = $("#status-tab tbody > tr");
      // var rows = document.querySelectorAll("#status-tab tbody > tr");
      // rows = Array.from(rows);
      // alert(rows);
      // rows.forEach(row => {
      // var depTypeInput = row.querySelector("#dependency-type");
      // alert("value " + depTypeInput.value);
      // depTypeInput.style.backgroundColor = "red";
      // depTypeInput.addEventListener("change", () =>
      // alert("value", depTypeInput.value)
      // );
      // var companyField = row.querySelector("#status-company-field");
      // var contactField = row.querySelector("#status-contact-field");
      // depTypeInput.change(() => alert(depTypeInput.val()));
      // depTypeInput.addEventListener("change", () => {
      //   alert(depTypeInput.val());
      // });
      // });
    }
    renderStatusTab(
      dependencyTypeOptions,
      entityTypeOptions,
      companyFieldOptions,
      contactFieldOptions
    ) {
      // const statusTab = document.querySelector("#status-tab");
      var statusTab = $("#status-tab");
      this.getTemplate("status-tab")
        .then(statusTemplate => {
          return statusTemplate.render({
            statusDependencyTypeOptions: dependencyTypeOptions,
            statusEntityTypeOptions: entityTypeOptions,
            statusCompanyFieldOptions: companyFieldOptions,
            statusContactFieldOptions: contactFieldOptions,
          });
        })
        .then(result => statusTab.append($(result)[0]));
      this.addRowListeners(
        dependencyTypeOptions,
        entityTypeOptions,
        companyFieldOptions,
        contactFieldOptions
      );
    }

    addRow(
      dependencyTypeOptions,
      entityTypeOptions,
      companyFieldOptions,
      contactFieldOptions
    ) {
      this.renderTableRow(
        dependencyTypeOptions,
        entityTypeOptions,
        companyFieldOptions,
        contactFieldOptions
      );
    }

    renderTableRow(
      dependencyTypeOptions,
      entityTypeOptions,
      companyFieldOptions,
      contactFieldOptions
    ) {
      var tableBody = $("#status-tbody");
      // var tableBody = document.querySelector("#status-tbody");
      this.getTemplate("table-row")
        .then(rowTemplate => {
          return rowTemplate.render({
            statusDependencyTypeOptions: dependencyTypeOptions,
            statusEntityTypeOptions: entityTypeOptions,
            statusCompanyFieldOptions: companyFieldOptions,
            statusContactFieldOptions: contactFieldOptions,
          });
        })
        .then(result => {
          tableBody.append($(result)[0]);
        });
    }

    renderContactTab(contactItems, leadItems) {
      const contactTab = $("#contact-tab");
      this.getTemplate("contact-tab")
        .then(contactTemplate =>
          $(
            contactTemplate.render({
              contactFieldOptions: contactItems,
              contactLeadFieldOptions: leadItems,
            })
          )
        )
        .then(result => contactTab.append(result));
    }

    renderCompanyTab(companyFieldOptions, companyLeadFieldOptions) {
      const companyTab = $("#company-tab");
      this.getTemplate("company-tab")
        .then(companyTemplate =>
          $(
            companyTemplate.render({
              companyFieldOptions: companyFieldOptions,
              companyLeadFieldOptions: companyLeadFieldOptions,
            })
          )
        )
        .then(result => companyTab.append(result));
    }

    renderPage() {
      this.getTemplate("entirety").then(entireTemplate => {
        let $page = $("#work_area");
        const {
          companyFields,
          leadFields,
          contactFields,
          dependencyType,
          entityType,
        } = data;
        const companyItems = this.optionsToItems({ options: companyFields });
        const leadItems = this.optionsToItems({ options: leadFields });
        const contactItems = this.optionsToItems({ options: contactFields });
        const dependencyItems = this.optionsToItems({
          options: dependencyType,
        });
        const entityItems = this.optionsToItems({ options: entityType });
        $page.append($(entireTemplate.render())[0]);

        this.renderContactTab(contactItems, leadItems);
        this.renderStatusTab(
          dependencyItems,
          entityItems,
          companyItems,
          contactItems
        );
        this.renderCompanyTab(companyItems, leadItems);
        var tabBtns = document.querySelectorAll("[data-content-selector]");
        var tabs = document.querySelectorAll("[data-content-tab]");
        tabBtns.forEach(btn => {
          btn.addEventListener("click", () => {
            const target = document.querySelector(btn.dataset.contentSelector);
            tabs.forEach(tab => {
              tab.classList.remove("active");
            });
            tabBtns.forEach(btn => btn.classList.remove("active"));
            target.classList.add("active");
            btn.classList.add("active");
            this.addDeleteButtonListeners();
            this.addRowListeners();
          });
        });

        var testButton = document.querySelector("#test-button");
        testButton.addEventListener("click", () => {
          this.addRow(dependencyItems, entityItems, companyItems, contactItems);
        });

        // document.addEventListener("click", () => this.addRowListeners());
        // var statusButton = document.querySelector("#status-button");
        // statusButton.addEventListener("click", () => {
        //   this.addRowListeners();
        // });
        // var select = $("#dependency-type");
        // // var select = document.querySelector("#dependency-type");
        // var contactFieldsBlock = document.querySelector(
        //   "#status-contact-field"
        // );
        // var companyFieldsBlock = document.querySelector(
        //   "#status-company-field"
        // );
        // // select.style.backgroundColor = "greenyellow";
        // // select.addEventListener("change", () => {
        // select.on("change", () => {
        //   switch (select.val()) {
        //     case "contact":
        //       contactFieldsBlock.style.display = "flex";
        //       companyFieldsBlock.style.display = "none";
        //       break;
        //     case "company":
        //       contactFieldsBlock.style.display = "none";
        //       companyFieldsBlock.style.display = "flex";
        //       break;
        //   }
        // });
      });
      // });
    }

    destroy() {
      this.isDestroyed = true;
    }
  }

  return function () {
    let self = this;
    let widget = new Widget(this, templatesRenderer(this));
    // var getTemplate = templatesRenderer(this);
    this.callbacks = {
      init: function () {
        var settings = self.get_settings();
        var styles = [
          "style.css",
          "status-tab.css",
          "contact-tab.css",
          "company-tab.css",
        ];
        styles.forEach(style => {
          $("head").append(
            '<link href="' +
              settings.path +
              "/" +
              style +
              "?v=" +
              settings.version +
              '" type="text/css" rel="stylesheet">'
          );
        });
        return true;
      },
      advancedSettings: function () {
        widget.renderPage();
        return true;
      },
      render: () => true,
      bind_actions: function () {
        return true;
      },
      destroy: () => widget.destroy(),
      onSave: () => true,
    };
    return this;
  };
});

define([], function () {
  tabBtns = document.querySelectorAll("[data-content-selector]");
  tabs = document.querySelectorAll("[data-content-tab]");
  tabBtns.forEach(btn => {
    btn.addEventListener("click", () => {
      const target = document.querySelector(btn.dataset.contentSelector);
      tabs.forEach(tab => {
        tab.classList.remove("active");
      });
      target.classList.add("active");
    });
  });
  return true;
});

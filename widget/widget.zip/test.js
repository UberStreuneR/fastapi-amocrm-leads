var data = {
  companyFields: [
    { value: "1", label: "Email" },
    { value: "2", label: "Web" },
    { value: "3", label: "Адрес" },
    { value: "4", label: "Примечание" },
    { value: "5", label: "Почтовый адрес" },
    { value: "6", label: "Последняя оплата" },
    { value: "7", label: "Уровень компании" },
    { value: "8", label: "Сумма оплат за 6 мес." },
  ],
  leadFields: [
    { value: "1", label: "Сообщ. в Телеграм" },
    { value: "2", label: "Кол-во успешных сделок за 6 мес." },
    { value: "3", label: "на дату" },
    { value: "4", label: "Этап 'Завершены работы'" },
    { value: "5", label: "Сделка для возврата залога?" },
    { value: "6", label: "Воронка Первичное этап Закрыто" },
  ],
  contactFields: [
    { value: "1", label: "Примечание" },
    { value: "2", label: "Регион" },
    { value: "3", label: "Уровень контакта" },
    { value: "4", label: "Кол-во успешных сделок за 6 мес." },
    { value: "5", label: "roistat" },
  ],
  dependencyType: [
    { value: "1", label: "От количества" },
    { value: "2", label: "От суммы" },
  ],
  entityType: [
    { value: "contact", label: "Контакт" },
    { value: "company", label: "Компания" },
  ],
};

define(["./templates.js"], function (templatesRenderer) {
  class Widget {
    constructor(widget, getTemplate) {
      this.widget = widget;
      this.getTemplate = getTemplate;
      this.isDestroyed = false;
    }

    optionsToItems({ options, values, prefix } = {}) {
      return options.reduce((items, option) => {
        let item = { id: option.value, option: option.label };

        if (values && prefix) {
          item.name = `${prefix}${option.value}`;
          item.is_checked = values.includes(option.value);
          item.option = `${option.group}. ${item.option}`;
        }

        items.push(item);
        return items;
      }, []);
    }

    returnItems() {
      const {
        companyFields,
        leadFields,
        contactFields,
        dependencyType,
        entityType,
      } = data;
      const companyItems = this.optionsToItems({ options: companyFields });
      const leadItems = this.optionsToItems({ options: leadFields });
      const contactItems = this.optionsToItems({ options: contactFields });
      const dependencyItems = this.optionsToItems({
        options: dependencyType,
      });
      const entityItems = this.optionsToItems({ options: entityType });
      return {
        companyItems,
        leadItems,
        contactItems,
        dependencyItems,
        entityItems,
      };
    }

    addDeleteButtonListeners() {
      var tbody = document.querySelector("#status-tab tbody");
      tbody.addEventListener("click", e => {
        if (
          e.target &&
          e.target.nodeName == "SPAN" &&
          e.target.id == "delete-row-icon"
        ) {
          var deleteBtns = $("#delete-row-icon");
          // var deleteBtns = document.querySelectorAll("#delete-row-icon");
          deleteBtns = Array.from(deleteBtns);
          var rows = $("#status-tab tbody > tr");
          // var rows = document.querySelectorAll("#status-tab tbody > tr");
          rows = Array.from(rows);
          rows[deleteBtns.indexOf(e.target)].remove();
        }
      });
    }

    addTabButtonsListeners() {
      var tabBtns = document.querySelectorAll("[data-content-selector]");
      var tabs = document.querySelectorAll("[data-content-tab]");
      tabBtns.forEach(btn => {
        btn.addEventListener("click", () => {
          const target = document.querySelector(btn.dataset.contentSelector);
          tabs.forEach(tab => {
            tab.classList.remove("active");
          });
          tabBtns.forEach(btn => btn.classList.remove("active"));
          target.classList.add("active");
          btn.classList.add("active");
        });
      });
    }

    renderStatusTab(
      dependencyTypeOptions,
      entityTypeOptions,
      companyFieldOptions,
      contactFieldOptions,
      callback
    ) {
      // const statusTab = document.querySelector("#status-tab");
      var statusTab = $("#status-tab");
      this.getTemplate("status-tab")
        .then(statusTemplate => {
          return statusTemplate.render({
            statusDependencyTypeOptions: dependencyTypeOptions,
            statusEntityTypeOptions: entityTypeOptions,
            statusCompanyFieldOptions: companyFieldOptions,
            statusContactFieldOptions: contactFieldOptions,
          });
        })
        .then(result => {
          statusTab.append($(result));
          callback();
        });
    }

    renderTableRow(
      dependencyTypeOptions,
      entityTypeOptions,
      companyFieldOptions,
      contactFieldOptions
    ) {
      var tableBody = $("#status-tbody");
      this.getTemplate("table-row")
        .then(rowTemplate => {
          return rowTemplate.render({
            statusDependencyTypeOptions: dependencyTypeOptions,
            statusEntityTypeOptions: entityTypeOptions,
            statusCompanyFieldOptions: companyFieldOptions,
            statusContactFieldOptions: contactFieldOptions,
          });
        })
        .then(result => {
          tableBody.append($(result));
        });
    }

    renderContactTab(contactItems, leadItems) {
      const contactTab = $("#contact-tab");
      this.getTemplate("contact-tab")
        .then(contactTemplate =>
          contactTemplate.render({
            contactFieldOptions: contactItems,
            contactLeadFieldOptions: leadItems,
          })
        )
        .then(result => contactTab.append($(result)));
    }

    renderCompanyTab(companyFieldOptions, companyLeadFieldOptions) {
      const companyTab = $("#company-tab");
      this.getTemplate("company-tab")
        .then(companyTemplate =>
          $(
            companyTemplate.render({
              companyFieldOptions: companyFieldOptions,
              companyLeadFieldOptions: companyLeadFieldOptions,
            })
          )
        )
        .then(result => companyTab.append(result));
    }

    renderSkeleton(callback) {
      this.getTemplate("entirety").then(entireTemplate => {
        let $page = $("#work_area");
        $page.append($(entireTemplate.render()));
        callback();
      });
    }

    renderPage() {
      this.renderSkeleton(() => {
        this.addTabButtonsListeners();
        const {
          companyItems,
          leadItems,
          contactItems,
          dependencyItems,
          entityItems,
        } = this.returnItems();
        this.renderContactTab(contactItems, leadItems);
        this.renderStatusTab(
          dependencyItems,
          entityItems,
          companyItems,
          contactItems,
          () => this.addDeleteButtonListeners()
        );
        this.renderCompanyTab(companyItems, leadItems);
      });
    }

    destroy() {
      this.isDestroyed = true;
    }
  }

  return function () {
    let self = this;
    let widget = new Widget(this, templatesRenderer(this));
    // var getTemplate = templatesRenderer(this);
    this.callbacks = {
      init: function () {
        var settings = self.get_settings();
        var styles = [
          "style.css",
          "status-tab.css",
          "contact-tab.css",
          "company-tab.css",
        ];
        styles.forEach(style => {
          $("head").append(
            '<link href="' +
              settings.path +
              "/" +
              style +
              "?v=" +
              settings.version +
              '" type="text/css" rel="stylesheet">'
          );
        });
        return true;
      },
      advancedSettings: function () {
        widget.renderPage();
        return true;
      },
      render: () => true,
      bind_actions: function () {
        return true;
      },
      destroy: () => widget.destroy(),
      onSave: () => true,
    };
    return this;
  };
});
